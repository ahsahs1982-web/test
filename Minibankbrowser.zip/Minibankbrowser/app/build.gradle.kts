import java.util.Date
import java.text.SimpleDateFormat

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ГЕНЕРАЦИЯ ВЕРСИИ: ГГММДДЧЧ (например: 24060915 - 2024 год, 06 месяц, 09 число, 15 часов)
val date = Date()
val formattedDateCode = SimpleDateFormat("yyMMddHH").format(date).toInt()
val formattedVersionName = SimpleDateFormat("1.0.yyMMdd").format(date)

android {
    namespace = "com.example.minibankbrowser"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.example.minibankbrowser"
        minSdk = 29 // Android 10
        targetSdk = 33

        // Автоматические версии
        versionCode = formattedDateCode
        versionName = formattedVersionName

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Игнорируем ошибки проверки Lint для быстрой сборки без SSL-проблем
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    // Базовые библиотеки Android
    implementation("androidx.core:core-ktx:1.9.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Библиотека для сохранения списка банков в формате JSON
    implementation("com.google.code.gson:gson:2.10.1")

    // Библиотека для фоновых задач (нужна для имитации подключения ADB через сокеты)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.4")
}