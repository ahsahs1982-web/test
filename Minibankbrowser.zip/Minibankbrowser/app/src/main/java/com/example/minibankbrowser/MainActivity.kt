package com.example.minibankbrowser

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Site(var name: String, var url: String)

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var layoutList: View
    private lateinit var layoutBrowser: View
    private lateinit var extraButtons: View
    private lateinit var navPanel: View
    private lateinit var btnResume: Button
    private lateinit var sites: MutableList<Site>
    private var currentActiveUrl: String? = null
    private var currentDpi: Int = 100

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WebView.setWebContentsDebuggingEnabled(true)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        layoutList = findViewById(R.id.layoutList)
        layoutBrowser = findViewById(R.id.layoutBrowser)
        extraButtons = findViewById(R.id.extraButtons)
        navPanel = findViewById(R.id.navPanel)
        btnResume = findViewById(R.id.btnResume)
        val listView: ListView = findViewById(R.id.listView)
        val btnHub: Button = findViewById(R.id.btnHub)
        val txtVersion: TextView = findViewById(R.id.txtVersion)

        val prefs = getSharedPreferences("data", Context.MODE_PRIVATE)
        currentDpi = prefs.getInt("user_dpi", 100)

        setupWebView()
        loadSites(listView)

        try {
            val pInfo = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(packageName, 0)
            }
            txtVersion.text = "Build:${pInfo.versionName} | DPI:${currentDpi}%"
        } catch (e: Exception) { e.printStackTrace() }

        btnHub.setOnClickListener {
            extraButtons.visibility = if (extraButtons.visibility == View.GONE) View.VISIBLE else View.GONE
            btnHub.text = if (extraButtons.visibility == View.VISIBLE) "✕" else "●"
            navPanel.bringToFront()
        }

        findViewById<Button>(R.id.btnDebug).setOnClickListener { showDebugMenu() }
        findViewById<Button>(R.id.btnDpi).setOnClickListener { showDpiDialog() }
        findViewById<Button>(R.id.btnWebBack).setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        findViewById<Button>(R.id.btnWebForward).setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        findViewById<Button>(R.id.btnBackToList).setOnClickListener { closeBrowser() }

        btnResume.setOnClickListener {
            layoutList.visibility = View.GONE
            layoutBrowser.visibility = View.VISIBLE
            navPanel.bringToFront()
        }

        findViewById<Button>(R.id.btnAddSite).setOnClickListener { showAddEditDialog(-1, listView) }

        listView.setOnItemClickListener { _, _, i, _ -> openBrowser(sites[i].url) }
        listView.setOnItemLongClickListener { _, _, i, _ -> showActionDialog(i, listView); true }
    }

    // --- ADB SHELL EXECUTION LOGIC ---
    private fun sendAdbShell(command: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val socket = Socket("127.0.0.1", 5555)
                val out = socket.getOutputStream()

                // 1. Отправляем запрос на открытие shell-сессии
                val cmd = "shell:$command\u0000"
                val connectionPacket = createAdbPacket("OPEN", 1, 0, cmd.toByteArray())
                out.write(connectionPacket)
                out.flush()

                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Команда отправлена", Toast.LENGTH_SHORT).show()
                }
                socket.close()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Ошибка ADB: проверьте порт 5555", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun createAdbPacket(cmd: String, arg0: Int, arg1: Int, data: ByteArray): ByteArray {
        val buffer = ByteBuffer.allocate(24 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        val commandInt = cmd.reversed().fold(0) { acc, c -> (acc shl 8) or c.code }
        buffer.putInt(commandInt)
        buffer.putInt(arg0)
        buffer.putInt(arg1)
        buffer.putInt(data.size)
        buffer.putInt(data.fold(0) { acc, b -> acc + (b.toInt() and 0xFF) })
        buffer.putInt(commandInt.inv())
        buffer.put(data)
        return buffer.array()
    }

    // --- ДИАЛОГ СИСТЕМНЫХ НАСТРОЕК (DPI И ТАЙМАУТ) ---
    private fun showSystemSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_system, null)
        val editDpi = view.findViewById<EditText>(R.id.editSysDpi)
        val editTimeout = view.findViewById<EditText>(R.id.editScreenTimeout)

        AlertDialog.Builder(this)
            .setTitle("СИСТЕМНЫЕ ОПЦИИ")
            .setView(view)
            .setPositiveButton("ПРИМЕНИТЬ") { _, _ ->
                val dpi = editDpi.text.toString().toIntOrNull()
                val minutes = editTimeout.text.toString().toIntOrNull()

                // Команда изменения DPI (wm density)
                if (dpi != null) {
                    val cmd = if (dpi == 0) "wm density reset" else "wm density $dpi"
                    sendAdbShell(cmd)
                }

                // Команда изменения таймаута (в миллисекундах)
                if (minutes != null) {
                    val ms = if (minutes == 0) 30000 else minutes * 60 * 1000
                    sendAdbShell("settings put system screen_off_timeout $ms")
                }
            }
            .setNegativeButton("ОТМЕНА", null).show()
    }

    private fun showDebugMenu() {
        val options = arrayOf("Системный DPI / Экран", "Очистить Кэш/Cookies", "Тех. инфо")
        AlertDialog.Builder(this).setTitle("ОТЛАДКА").setItems(options) { _, which ->
            when (which) {
                0 -> showSystemSettingsDialog()
                1 -> { CookieManager.getInstance().removeAllCookies(null); webView.clearCache(true); webView.reload() }
                2 -> AlertDialog.Builder(this).setMessage("UA: ${webView.settings.userAgentString}").show()
            }
            extraButtons.visibility = View.GONE
        }.show()
    }

    // --- ОСТАЛЬНОЙ КОД (Внутренний DPI, WebView, Загрузка) ---
    private fun showDpiDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_dpi, null)
        val editDpi = dialogView.findViewById<EditText>(R.id.editDpiValue)
        val seekBar = dialogView.findViewById<SeekBar>(R.id.seekBarDpi)
        editDpi.setText(currentDpi.toString())
        seekBar.progress = currentDpi - 50
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) editDpi.setText((p + 50).toString())
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        AlertDialog.Builder(this).setTitle("МАСШТАБ (APP)").setView(dialogView).setPositiveButton("ОК") { _, _ ->
            currentDpi = editDpi.text.toString().toIntOrNull()?.coerceIn(50, 200) ?: 100
            webView.settings.textZoom = currentDpi
            getSharedPreferences("data", Context.MODE_PRIVATE).edit().putInt("user_dpi", currentDpi).apply()
            extraButtons.visibility = View.GONE
        }.show()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.textZoom = currentDpi
        s.userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
        webView.setBackgroundColor(0x000000)
        webView.webViewClient = WebViewClient()
    }

    private fun openBrowser(url: String) {
        val target = if (!url.startsWith("http")) "https://$url" else url
        layoutList.visibility = View.GONE
        layoutBrowser.visibility = View.VISIBLE
        if (currentActiveUrl != target) { webView.loadUrl(target); currentActiveUrl = target }
        btnResume.visibility = View.VISIBLE
    }

    private fun closeBrowser() { layoutBrowser.visibility = View.GONE; layoutList.visibility = View.VISIBLE }

    private fun loadSites(lv: ListView) {
        val prefs = getSharedPreferences("data", Context.MODE_PRIVATE)
        val json = prefs.getString("sites", null)
        sites = if (json == null) {
            mutableListOf(Site("ЯНДЕКС ПЭЙ", "pay.yandex.ru"), Site("СБЕР", "online.sberbank.ru"), Site("ТИНЬКОФФ", "tinkoff.ru/login/"), Site("ВТБ ОНЛАЙН", "online.vtb.ru"), Site("СОВКОМБАНК", "online.sovcombank.ru"), Site("ОЗОН", "ozon.ru"))
        } else {
            Gson().fromJson(json, object : TypeToken<MutableList<Site>>() {}.type)
        }
        lv.adapter = ArrayAdapter(this, R.layout.item_site, sites.map { it.name })
    }

    private fun saveSites() {
        val prefs = getSharedPreferences("data", Context.MODE_PRIVATE)
        prefs.edit().putString("sites", Gson().toJson(sites)).apply()
    }

    private fun showAddEditDialog(pos: Int, lv: ListView) {
        val view = layoutInflater.inflate(R.layout.dialog_edit, null)
        val nInp = view.findViewById<EditText>(R.id.editName); val uInp = view.findViewById<EditText>(R.id.editUrl)
        if (pos != -1) { nInp.setText(sites[pos].name); uInp.setText(sites[pos].url) }
        AlertDialog.Builder(this).setTitle("САЙТ").setView(view).setPositiveButton("OK") { _, _ ->
            val s = Site(nInp.text.toString().uppercase(), uInp.text.toString())
            if (pos == -1) sites.add(s) else sites[pos] = s
            saveSites(); lv.adapter = ArrayAdapter(this, R.layout.item_site, sites.map { it.name })
        }.show()
    }

    private fun showActionDialog(pos: Int, lv: ListView) {
        AlertDialog.Builder(this).setItems(arrayOf("Изменить", "Удалить")) { _, w ->
            if (w == 0) showAddEditDialog(pos, lv)
            else { sites.removeAt(pos); saveSites(); lv.adapter = ArrayAdapter(this, R.layout.item_site, sites.map { it.name }) }
        }.show()
    }

    override fun onBackPressed() {
        if (layoutBrowser.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack() else closeBrowser()
        } else super.onBackPressed()
    }
}