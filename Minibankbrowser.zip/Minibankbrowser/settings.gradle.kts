pluginManagement {
    repositories {
        maven { url = uri("https://mirrors.cloud.tencent.com/nexus/content/repositories/central/") }
        maven { url = uri("https://mirrors.cloud.tencent.com/nexus/content/repositories/google/") }
        maven { url = uri("https://mirrors.cloud.tencent.com/nexus/content/repositories/gradle-plugin/") }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.10.0"
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven { url = uri("https://mirrors.cloud.tencent.com/nexus/content/repositories/central/") }
        maven { url = uri("https://mirrors.cloud.tencent.com/nexus/content/repositories/google/") }
        google()
        mavenCentral()
    }
}

rootProject.name = "Minibankbrowser"
include(":app")
 